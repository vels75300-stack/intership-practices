import type { ReactNode } from "react";

export function Section({
  eyebrow,
  title,
  description,
  children,
  className = "",
  centered = true,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children?: ReactNode;
  className?: string;
  centered?: boolean;
}) {
  return (
    <section className={`mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 ${className}`}>
      <div className={`mb-12 ${centered ? "text-center" : ""}`}>
        {eyebrow && (
          <span className="inline-block rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            {eyebrow}
          </span>
        )}
        <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">{title}</h2>
        {description && (
          <p className={`mt-4 text-base text-muted-foreground sm:text-lg ${centered ? "mx-auto max-w-2xl" : "max-w-2xl"}`}>
            {description}
          </p>
        )}
      </div>
      {children}
    </section>
  );
}
