import { createFileRoute } from "@tanstack/react-router";
import { UserPlus, UsersRound, ListChecks, FileUp, MessageCircle, Award } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Section } from "@/components/Section";

export const Route = createFileRoute("/workflow")({
  head: () => ({
    meta: [
      { title: "Workflow — InternFlow" },
      { name: "description", content: "Step-by-step: Admin assigns mentor → Mentor assigns tasks → Intern submits reports → Mentor provides feedback." },
      { property: "og:title", content: "Workflow — InternFlow" },
      { property: "og:description", content: "See how InternFlow flows from onboarding to performance reviews in six clear steps." },
    ],
  }),
  component: WorkflowPage,
});

const steps = [
  { icon: UserPlus, title: "Onboard Interns", desc: "Admin invites interns and adds them to a cohort with role assignment.", actor: "Admin" },
  { icon: UsersRound, title: "Assign Mentors", desc: "Admin pairs each intern (or group) with a qualified mentor.", actor: "Admin" },
  { icon: ListChecks, title: "Distribute Tasks", desc: "Mentor creates tasks with deadlines, resources, and priorities.", actor: "Mentor" },
  { icon: FileUp, title: "Submit Reports", desc: "Intern completes work and submits structured progress reports.", actor: "Intern" },
  { icon: MessageCircle, title: "Provide Feedback", desc: "Mentor reviews submissions and leaves actionable feedback.", actor: "Mentor" },
  { icon: Award, title: "Performance Review", desc: "Final scorecard generated automatically for the program.", actor: "Admin" },
];

const actorColor: Record<string, string> = {
  Admin: "bg-primary/15 text-primary",
  Mentor: "bg-accent/20 text-accent-foreground",
  Intern: "bg-success/15 text-success",
};

function WorkflowPage() {
  return (
    <div className="bg-gradient-mesh">
      <Section
        eyebrow="Workflow"
        title="How InternFlow works"
        description="A clear, six-step journey from onboarding to performance review — designed to be intuitive for everyone involved."
      >
        <div className="relative">
          {/* connecting line */}
          <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-primary/30 via-accent/30 to-transparent lg:block" />

          <div className="space-y-8">
            {steps.map((s, i) => (
              <div
                key={s.title}
                className={`relative grid items-center gap-6 lg:grid-cols-2 ${i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""}`}
              >
                <Card className="relative overflow-hidden p-6 shadow-card transition-smooth hover:shadow-elegant animate-fade-up">
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground shadow-glow">
                      <s.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-muted-foreground">Step {i + 1}</span>
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${actorColor[s.actor]}`}>{s.actor}</span>
                      </div>
                      <h3 className="mt-1 text-xl font-semibold">{s.title}</h3>
                      <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
                    </div>
                  </div>
                </Card>

                {/* center dot */}
                <div className="absolute left-1/2 top-1/2 hidden h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-primary shadow-glow ring-4 ring-background lg:block" />

                <div className="hidden lg:block">
                  <div className={`mx-auto flex h-32 w-32 items-center justify-center rounded-3xl bg-gradient-to-br ${
                    i % 3 === 0 ? "from-primary to-primary-glow" : i % 3 === 1 ? "from-accent to-primary" : "from-primary-glow to-accent"
                  } opacity-90 shadow-elegant transition-bounce hover:scale-105`}>
                    <s.icon className="h-12 w-12 text-primary-foreground" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>
    </div>
  );
}
