import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, BarChart3, Users, ClipboardList, Bell, Sparkles, Trophy, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "InternFlow — Modern Internship Management System" },
      { name: "description", content: "Streamline internships end-to-end. Manage admins, mentors and interns with task tracking, reports and performance analytics." },
      { property: "og:title", content: "InternFlow — Modern Internship Management System" },
      { property: "og:description", content: "Streamline internships end-to-end. Manage admins, mentors and interns with task tracking, reports and performance analytics." },
    ],
  }),
  component: Index,
});

const stats = [
  { value: "10k+", label: "Active Interns" },
  { value: "1.2k", label: "Mentors" },
  { value: "98%", label: "Completion Rate" },
  { value: "240", label: "Partner Orgs" },
];

const highlights = [
  { icon: ClipboardList, title: "Task Management", desc: "Create, assign and track tasks with deadlines and priorities." },
  { icon: BarChart3, title: "Progress Tracking", desc: "Real-time analytics on intern performance and milestones." },
  { icon: Bell, title: "Smart Notifications", desc: "Stay updated on submissions, feedback and announcements." },
  { icon: Users, title: "Role Management", desc: "Granular access for admins, mentors and interns." },
];

const testimonials = [
  { name: "Sarah Chen", role: "HR Director, Apex Co.", quote: "InternFlow turned our chaotic spreadsheets into a streamlined program. Mentors actually love using it." },
  { name: "Marcus Patel", role: "Engineering Mentor", quote: "Assigning tasks and reviewing reports takes minutes now. The dashboard is genuinely beautiful." },
  { name: "Aisha Rahman", role: "Software Intern", quote: "I always know what's next. Feedback loops are fast and my growth is visible week by week." },
];

function Index() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-mesh">
        <div className="mx-auto max-w-7xl px-4 pb-24 pt-20 sm:px-6 lg:px-8 lg:pt-28">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="animate-fade-up">
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-background/80 px-3 py-1 text-xs font-semibold text-primary backdrop-blur">
                <Sparkles className="h-3.5 w-3.5" />
                Internship Management, Reimagined
              </span>
              <h1 className="mt-5 text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
                Run internships <span className="text-gradient">that actually work.</span>
              </h1>
              <p className="mt-5 max-w-xl text-lg text-muted-foreground">
                InternFlow brings admins, mentors and interns onto one elegant platform — with task management, progress tracking, reports and feedback baked in.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button asChild size="lg" className="bg-gradient-primary shadow-glow transition-smooth hover:scale-[1.02]">
                  <Link to="/features">View Features <ArrowRight className="ml-2 h-4 w-4" /></Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="transition-smooth hover:bg-secondary">
                  <Link to="/dashboard">Explore Dashboard</Link>
                </Button>
                <Button asChild size="lg" variant="ghost">
                  <Link to="/contact">Contact Us</Link>
                </Button>
              </div>

              <div className="mt-10 grid grid-cols-4 gap-4 border-t border-border/60 pt-6">
                {stats.map((s) => (
                  <div key={s.label}>
                    <div className="text-2xl font-bold text-gradient sm:text-3xl">{s.value}</div>
                    <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero mock dashboard */}
            <div className="relative animate-fade-in">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-primary opacity-20 blur-3xl" />
              <Card className="relative overflow-hidden border border-border/80 bg-card/90 p-5 shadow-elegant backdrop-blur">
                <div className="flex items-center justify-between border-b border-border pb-3">
                  <div className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
                    <div className="h-2.5 w-2.5 rounded-full bg-warning" />
                    <div className="h-2.5 w-2.5 rounded-full bg-success" />
                  </div>
                  <span className="text-xs text-muted-foreground">internflow.app/dashboard</span>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-3">
                  {[
                    { label: "Active Tasks", value: "24", trend: "+12%" },
                    { label: "Submissions", value: "47", trend: "+8%" },
                    { label: "Avg Score", value: "92", trend: "+3%" },
                  ].map((m) => (
                    <div key={m.label} className="rounded-xl bg-gradient-soft p-3">
                      <div className="text-[11px] text-muted-foreground">{m.label}</div>
                      <div className="mt-1 text-xl font-bold">{m.value}</div>
                      <div className="text-[10px] font-semibold text-success">{m.trend}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 rounded-xl border border-border bg-background p-4">
                  <div className="mb-3 flex items-center justify-between text-xs font-semibold">
                    <span>Recent Tasks</span>
                    <span className="text-primary">View all</span>
                  </div>
                  {[
                    { t: "Build login page", s: "In Review", c: "warning" },
                    { t: "Submit weekly report", s: "Done", c: "success" },
                    { t: "Refactor API client", s: "In Progress", c: "primary" },
                  ].map((row, i) => (
                    <div key={i} className="flex items-center justify-between border-t border-border py-2.5 first:border-0 first:pt-0">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                        {row.t}
                      </div>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                        row.c === "success" ? "bg-success/15 text-success" :
                        row.c === "warning" ? "bg-warning/20 text-warning-foreground" :
                        "bg-primary/15 text-primary"
                      }`}>{row.s}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-end gap-1.5">
                  {[40, 65, 50, 80, 70, 95, 85].map((h, i) => (
                    <div key={i} className="flex-1 rounded-t bg-gradient-primary opacity-90" style={{ height: `${h * 0.6}px` }} />
                  ))}
                </div>
              </Card>

              <div className="absolute -right-4 -top-4 hidden animate-float rounded-2xl bg-card p-3 shadow-elegant md:block">
                <Trophy className="h-5 w-5 text-warning" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HIGHLIGHTS */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <span className="inline-block rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
            Why InternFlow
          </span>
          <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">Everything you need, nothing you don't</h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Purpose-built for educational institutions and companies running internship programs.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {highlights.map((h) => (
            <Card key={h.title} className="group p-6 shadow-card transition-smooth hover:-translate-y-1 hover:shadow-elegant">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground shadow-md transition-bounce group-hover:scale-110">
                <h.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{h.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{h.desc}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-gradient-soft py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <span className="inline-block rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
              Loved by teams
            </span>
            <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">What people say</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {testimonials.map((t) => (
              <Card key={t.name} className="p-6 shadow-card transition-smooth hover:shadow-elegant">
                <Quote className="h-6 w-6 text-primary/40" />
                <p className="mt-3 text-sm leading-relaxed">{t.quote}</p>
                <div className="mt-5 flex items-center gap-3 border-t border-border pt-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-primary text-sm font-bold text-primary-foreground">
                    {t.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div>
                    <div className="text-sm font-semibold">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.role}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-hero p-10 text-center text-primary-foreground shadow-elegant sm:p-16">
          <div className="absolute inset-0 bg-gradient-mesh opacity-30" />
          <div className="relative">
            <h2 className="text-3xl font-bold sm:text-4xl">Ready to elevate your internship program?</h2>
            <p className="mx-auto mt-4 max-w-xl text-base text-primary-foreground/85">
              Explore the dashboards, see the workflow, and discover how InternFlow can fit your team.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Button asChild size="lg" variant="secondary" className="shadow-md">
                <Link to="/dashboard">Explore Dashboard</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
