import { createFileRoute } from "@tanstack/react-router";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Section } from "@/components/Section";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — InternFlow" },
      { name: "description", content: "Frequently asked questions about InternFlow, the internship management system." },
      { property: "og:title", content: "FAQ — InternFlow" },
      { property: "og:description", content: "Answers to the most common questions about InternFlow." },
    ],
  }),
  component: FaqPage,
});

const faqs = [
  { q: "Who is InternFlow built for?", a: "Universities, bootcamps, and companies running structured internship programs that need to coordinate admins, mentors, and interns in one place." },
  { q: "What roles does the platform support?", a: "Three primary roles: Admin (program oversight), Mentor (task assignment and feedback), and Intern (task delivery and reporting). Each role has a tailored dashboard." },
  { q: "Can I run multiple internship cohorts?", a: "Yes. InternFlow supports multi-tenant programs, so you can manage multiple cohorts, departments or partner organizations from a single workspace." },
  { q: "How are reports submitted and reviewed?", a: "Interns submit structured reports with attachments. Mentors get notified instantly and can leave feedback in-line, with star ratings and comments." },
  { q: "Is the data secure?", a: "Absolutely. InternFlow uses industry-standard encryption, role-based access control, and comprehensive audit logs to keep your data safe." },
  { q: "Does this site have a working backend?", a: "This is a visual prototype showcasing the design and structure. The forms and dashboards demonstrate the experience without a live backend." },
  { q: "Can I customize roles and permissions?", a: "Yes. Admins can fine-tune permissions per role, restrict access to specific cohorts, or define custom workflows for unique programs." },
  { q: "How do interns receive feedback?", a: "Through the in-app feedback panel, with notifications by email and in-app alerts. Feedback is structured with ratings, comments, and improvement suggestions." },
];

function FaqPage() {
  return (
    <div className="bg-gradient-mesh">
      <Section
        eyebrow="FAQ"
        title="Frequently asked questions"
        description="Quick answers to the things people ask us most."
      >
        <div className="mx-auto max-w-3xl rounded-2xl border border-border bg-card p-2 shadow-card sm:p-4">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((f, i) => (
              <AccordionItem key={i} value={`item-${i}`} className="border-border">
                <AccordionTrigger className="px-4 text-left text-base font-semibold hover:no-underline">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="px-4 text-sm leading-relaxed text-muted-foreground">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </Section>
    </div>
  );
}
