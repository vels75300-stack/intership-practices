import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, MapPin, Phone, Send, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Section } from "@/components/Section";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — InternFlow" },
      { name: "description", content: "Get in touch with the InternFlow team. Send us your questions or schedule a demo." },
      { property: "og:title", content: "Contact — InternFlow" },
      { property: "og:description", content: "Reach the InternFlow team for inquiries, demos, and partnerships." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
    setForm({ name: "", email: "", message: "" });
  }

  return (
    <div className="bg-gradient-mesh">
      <Section
        eyebrow="Contact"
        title="Let's talk"
        description="Have a question, want a walkthrough, or interested in partnering? Drop us a line."
      >
        <div className="grid gap-8 lg:grid-cols-5">
          <Card className="lg:col-span-3 p-8 shadow-elegant">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    required
                    placeholder="Jane Doe"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    placeholder="jane@example.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  required
                  rows={6}
                  placeholder="Tell us about your internship program..."
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                />
              </div>

              <Button type="submit" size="lg" className="w-full bg-gradient-primary shadow-md transition-smooth hover:shadow-glow sm:w-auto">
                {sent ? (
                  <><CheckCircle2 className="mr-2 h-4 w-4" /> Message Sent!</>
                ) : (
                  <>Send Message <Send className="ml-2 h-4 w-4" /></>
                )}
              </Button>

              {sent && (
                <p className="animate-fade-in text-sm text-success">
                  Thanks! Your message was received. We'll be in touch shortly. (Demo only — no backend.)
                </p>
              )}
            </form>
          </Card>

          <div className="space-y-4 lg:col-span-2">
            {[
              { icon: Mail, label: "Email", value: "hello@internflow.app", desc: "We respond within 24 hours" },
              { icon: Phone, label: "Phone", value: "+1 (555) 123-4567", desc: "Mon–Fri, 9am to 6pm" },
              { icon: MapPin, label: "Office", value: "San Francisco, CA", desc: "1 Market St, Suite 400" },
            ].map((item) => (
              <Card key={item.label} className="p-5 shadow-card transition-smooth hover:-translate-y-0.5 hover:shadow-elegant">
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground shadow-md">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{item.label}</div>
                    <div className="mt-1 font-semibold">{item.value}</div>
                    <div className="text-sm text-muted-foreground">{item.desc}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </Section>
    </div>
  );
}
