import { createFileRoute } from "@tanstack/react-router";
import { ClipboardList, BarChart3, FileText, Bell, Users, Shield, Calendar, MessageSquare, Award, Zap, Globe, Lock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Section } from "@/components/Section";

export const Route = createFileRoute("/features")({
  head: () => ({
    meta: [
      { title: "Features — InternFlow" },
      { name: "description", content: "Discover task management, progress tracking, report submission, notifications, user management and more." },
      { property: "og:title", content: "Features — InternFlow" },
      { property: "og:description", content: "Everything InternFlow offers: tasks, reports, analytics, notifications and role-based access." },
    ],
  }),
  component: FeaturesPage,
});

const features = [
  { icon: ClipboardList, title: "Task Management", desc: "Create, assign, prioritize and track tasks with rich descriptions, deadlines, and tags.", color: "from-primary to-primary-glow" },
  { icon: BarChart3, title: "Progress Tracking", desc: "Visualize milestones, completion rates and individual growth with elegant charts.", color: "from-accent to-primary-glow" },
  { icon: FileText, title: "Report Submission", desc: "Interns submit weekly or milestone reports with attachments and rich formatting.", color: "from-primary-glow to-accent" },
  { icon: Bell, title: "Notifications", desc: "Real-time alerts for assignments, feedback, deadlines and announcements.", color: "from-warning to-primary-glow" },
  { icon: Users, title: "User Management", desc: "Onboard interns, mentors and admins with bulk import and granular roles.", color: "from-primary to-accent" },
  { icon: Shield, title: "Role-Based Access", desc: "Strict permissions ensure each user sees only what's relevant to them.", color: "from-accent to-primary" },
  { icon: Calendar, title: "Scheduling", desc: "Plan internships, milestones and 1:1 meetings with built-in calendars.", color: "from-primary-glow to-primary" },
  { icon: MessageSquare, title: "Feedback Loops", desc: "Mentors leave structured feedback on every submission to drive improvement.", color: "from-accent to-primary-glow" },
  { icon: Award, title: "Performance Reviews", desc: "Automated scorecards summarize performance over the internship period.", color: "from-warning to-accent" },
  { icon: Zap, title: "Lightning Fast", desc: "Built on a modern stack — pages feel instant on every device.", color: "from-primary to-primary-glow" },
  { icon: Globe, title: "Multi-Tenant", desc: "Run multiple cohorts, departments or organizations from one workspace.", color: "from-primary-glow to-accent" },
  { icon: Lock, title: "Secure by Design", desc: "Industry-standard encryption and audit trails on every action.", color: "from-accent to-primary" },
];

function FeaturesPage() {
  return (
    <div className="bg-gradient-mesh">
      <Section
        eyebrow="Features"
        title="A complete toolkit for internship programs"
        description="From the first task assignment to the final performance review — InternFlow has every step covered with thoughtful UX."
      >
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <Card
              key={f.title}
              className="group relative overflow-hidden p-6 shadow-card transition-smooth hover:-translate-y-1 hover:shadow-elegant animate-fade-up"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${f.color} opacity-0 transition-smooth group-hover:opacity-5`} />
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${f.color} text-primary-foreground shadow-md transition-bounce group-hover:scale-110 group-hover:rotate-3`}>
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </Card>
          ))}
        </div>
      </Section>
    </div>
  );
}
