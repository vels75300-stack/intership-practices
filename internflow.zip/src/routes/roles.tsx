import { createFileRoute, Link } from "@tanstack/react-router";
import { Shield, GraduationCap, UserCheck, ArrowRight, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/Section";

export const Route = createFileRoute("/roles")({
  head: () => ({
    meta: [
      { title: "User Roles — InternFlow" },
      { name: "description", content: "Three roles, one platform: Admin oversees programs, Mentors guide interns, and Interns deliver work." },
      { property: "og:title", content: "User Roles — InternFlow" },
      { property: "og:description", content: "Explore the responsibilities of Admin, Mentor and Intern in the InternFlow platform." },
    ],
  }),
  component: RolesPage,
});

const roles = [
  {
    icon: Shield,
    name: "Admin",
    tagline: "Program orchestrator",
    color: "from-primary to-primary-glow",
    duties: [
      "Create and manage internship programs",
      "Assign mentors to intern cohorts",
      "Monitor organization-wide analytics",
      "Manage users, roles and permissions",
      "Generate compliance and audit reports",
    ],
    mock: { title: "Admin Console", items: [
      { label: "Active Programs", value: "12" },
      { label: "Mentors Assigned", value: "48" },
      { label: "Pending Approvals", value: "7" },
    ]},
  },
  {
    icon: UserCheck,
    name: "Mentor",
    tagline: "Guide and reviewer",
    color: "from-accent to-primary",
    duties: [
      "Assign tasks with deadlines and resources",
      "Review intern reports and submissions",
      "Provide structured, actionable feedback",
      "Schedule 1:1 reviews and check-ins",
      "Track each intern's growth and milestones",
    ],
    mock: { title: "Mentor Workspace", items: [
      { label: "Interns Mentored", value: "6" },
      { label: "Tasks Assigned", value: "34" },
      { label: "Reviews Pending", value: "3" },
    ]},
  },
  {
    icon: GraduationCap,
    name: "Intern",
    tagline: "Learner and contributor",
    color: "from-primary-glow to-accent",
    duties: [
      "View assigned tasks and deadlines",
      "Submit weekly progress reports",
      "Receive structured mentor feedback",
      "Track personal growth and achievements",
      "Communicate with mentors and peers",
    ],
    mock: { title: "Intern Dashboard", items: [
      { label: "Tasks Open", value: "5" },
      { label: "Reports Submitted", value: "11" },
      { label: "Avg Score", value: "94" },
    ]},
  },
];

function RolesPage() {
  return (
    <div className="bg-gradient-mesh">
      <Section
        eyebrow="User Roles"
        title="Built around three core personas"
        description="Each role has a tailored experience — focused on what matters most to them, with no clutter."
      >
        <div className="grid gap-6 lg:grid-cols-3">
          {roles.map((r, i) => (
            <Card
              key={r.name}
              className="group relative overflow-hidden p-7 shadow-card transition-smooth hover:-translate-y-1 hover:shadow-elegant animate-fade-up"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${r.color} shadow-glow text-primary-foreground transition-bounce group-hover:scale-110`}>
                <r.icon className="h-6 w-6" />
              </div>
              <div className="mt-5">
                <div className="text-xs font-semibold uppercase tracking-wider text-primary">{r.tagline}</div>
                <h3 className="mt-1 text-2xl font-bold">{r.name}</h3>
              </div>
              <ul className="mt-5 space-y-2.5">
                {r.duties.map((d) => (
                  <li key={d} className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                    <span className="text-muted-foreground">{d}</span>
                  </li>
                ))}
              </ul>

              {/* Mini mock dashboard */}
              <div className="mt-6 rounded-xl border border-border bg-gradient-soft p-4">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-xs font-semibold">{r.mock.title}</span>
                  <span className="text-[10px] text-muted-foreground">Live preview</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {r.mock.items.map((m) => (
                    <div key={m.label} className="rounded-lg bg-background p-2.5 text-center">
                      <div className="text-base font-bold text-gradient">{m.value}</div>
                      <div className="text-[10px] text-muted-foreground">{m.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button asChild size="lg" className="bg-gradient-primary shadow-glow">
            <Link to="/dashboard">See full dashboards <ArrowRight className="ml-2 h-4 w-4" /></Link>
          </Button>
        </div>
      </Section>
    </div>
  );
}
