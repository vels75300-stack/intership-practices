import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shield, UserCheck, GraduationCap, Bell, Search, Plus, FileText, CheckCircle2, Clock, TrendingUp, Calendar, Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/Section";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard Preview — InternFlow" },
      { name: "description", content: "Static UI mockups of Admin, Mentor and Intern dashboards in InternFlow." },
      { property: "og:title", content: "Dashboard Preview — InternFlow" },
      { property: "og:description", content: "Take a tour through Admin, Mentor and Intern dashboards." },
    ],
  }),
  component: DashboardPage,
});

type RoleKey = "admin" | "mentor" | "intern";

function DashboardPage() {
  const [role, setRole] = useState<RoleKey>("admin");

  return (
    <div className="bg-gradient-mesh">
      <Section
        eyebrow="Dashboard Preview"
        title="See InternFlow in action"
        description="Switch between roles to explore mock dashboards. These are visual previews — not connected to a backend."
      >
        <div className="mx-auto mb-8 inline-flex w-full max-w-md items-center rounded-full border border-border bg-card p-1 shadow-card sm:mx-auto sm:flex">
          {([
            { k: "admin", label: "Admin", icon: Shield },
            { k: "mentor", label: "Mentor", icon: UserCheck },
            { k: "intern", label: "Intern", icon: GraduationCap },
          ] as const).map((r) => (
            <button
              key={r.k}
              onClick={() => setRole(r.k)}
              className={`flex flex-1 items-center justify-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-smooth ${
                role === r.k ? "bg-gradient-primary text-primary-foreground shadow-md" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <r.icon className="h-4 w-4" /> {r.label}
            </button>
          ))}
        </div>

        <div className="animate-fade-in">
          {role === "admin" && <AdminDashboard />}
          {role === "mentor" && <MentorDashboard />}
          {role === "intern" && <InternDashboard />}
        </div>
      </Section>
    </div>
  );
}

function ChromeBar({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-between border-b border-border bg-gradient-soft px-4 py-2.5">
      <div className="flex items-center gap-1.5">
        <div className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
        <div className="h-2.5 w-2.5 rounded-full bg-warning" />
        <div className="h-2.5 w-2.5 rounded-full bg-success" />
      </div>
      <span className="text-xs font-medium text-muted-foreground">{title}</span>
      <div className="flex items-center gap-2">
        <Search className="h-3.5 w-3.5 text-muted-foreground" />
        <Bell className="h-3.5 w-3.5 text-muted-foreground" />
      </div>
    </div>
  );
}

function StatCard({ label, value, trend, icon: Icon, color = "primary" }: { label: string; value: string; trend?: string; icon: React.ElementType; color?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm transition-smooth hover:shadow-md">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${color === "primary" ? "bg-primary/10 text-primary" : color === "success" ? "bg-success/10 text-success" : "bg-warning/15 text-warning-foreground"}`}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className="mt-3 text-2xl font-bold">{value}</div>
      {trend && <div className="mt-1 text-xs font-semibold text-success">↑ {trend}</div>}
    </div>
  );
}

function AdminDashboard() {
  return (
    <Card className="overflow-hidden shadow-elegant">
      <ChromeBar title="internflow.app/admin" />
      <div className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-2xl font-bold">Welcome back, Sarah</h3>
            <p className="text-sm text-muted-foreground">Here's what's happening across your programs.</p>
          </div>
          <Button size="sm" className="bg-gradient-primary"><Plus className="mr-1.5 h-4 w-4" /> New Program</Button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Active Programs" value="12" trend="2 new" icon={TrendingUp} />
          <StatCard label="Total Interns" value="184" trend="12%" icon={GraduationCap} color="success" />
          <StatCard label="Mentors" value="48" icon={UserCheck} />
          <StatCard label="Pending Approvals" value="7" icon={Clock} color="warning" />
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h4 className="font-semibold">Program Performance</h4>
              <span className="text-xs text-muted-foreground">Last 6 months</span>
            </div>
            <div className="flex h-44 items-end gap-2">
              {[55, 70, 60, 85, 75, 95, 88, 92, 80, 96, 90, 100].map((h, i) => (
                <div key={i} className="flex-1 rounded-t bg-gradient-primary opacity-90 transition-smooth hover:opacity-100" style={{ height: `${h}%` }} />
              ))}
            </div>
            <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
              {["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].map(m => <span key={m}>{m}</span>)}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-card p-5">
            <h4 className="mb-4 font-semibold">Recent Activity</h4>
            <ul className="space-y-3">
              {[
                { t: "New mentor onboarded", s: "2m ago", c: "bg-success" },
                { t: "Cohort 24-A launched", s: "1h ago", c: "bg-primary" },
                { t: "Report flagged for review", s: "3h ago", c: "bg-warning" },
                { t: "Performance review done", s: "1d ago", c: "bg-accent" },
              ].map((a, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs">
                  <span className={`mt-1.5 h-2 w-2 rounded-full ${a.c}`} />
                  <div className="flex-1">
                    <div className="font-medium">{a.t}</div>
                    <div className="text-muted-foreground">{a.s}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
}

function MentorDashboard() {
  const interns = [
    { name: "Aisha Rahman", task: "API Refactor", progress: 92, status: "On Track" },
    { name: "Diego Martinez", task: "UI Design Sys", progress: 75, status: "On Track" },
    { name: "Yuki Tanaka", task: "DB Migration", progress: 45, status: "At Risk" },
    { name: "Priya Nair", task: "Auth Module", progress: 88, status: "On Track" },
  ];

  return (
    <Card className="overflow-hidden shadow-elegant">
      <ChromeBar title="internflow.app/mentor" />
      <div className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-2xl font-bold">Hello, Marcus</h3>
            <p className="text-sm text-muted-foreground">You have 3 reports awaiting review.</p>
          </div>
          <Button size="sm" className="bg-gradient-primary"><Plus className="mr-1.5 h-4 w-4" /> Assign Task</Button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          <StatCard label="Interns Mentored" value="6" icon={GraduationCap} />
          <StatCard label="Tasks Assigned" value="34" trend="5 this week" icon={FileText} color="success" />
          <StatCard label="Reviews Pending" value="3" icon={Clock} color="warning" />
        </div>

        <div className="mt-6 rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <h4 className="font-semibold">My Interns</h4>
            <span className="text-xs text-muted-foreground">Live progress</span>
          </div>
          <div className="divide-y divide-border">
            {interns.map((i) => (
              <div key={i.name} className="flex items-center gap-4 px-5 py-4 transition-smooth hover:bg-secondary/40">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-primary text-sm font-bold text-primary-foreground">
                  {i.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="truncate text-sm font-semibold">{i.name}</div>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${i.status === "At Risk" ? "bg-warning/20 text-warning-foreground" : "bg-success/15 text-success"}`}>
                      {i.status}
                    </span>
                  </div>
                  <div className="mt-0.5 truncate text-xs text-muted-foreground">{i.task}</div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-gradient-primary transition-smooth" style={{ width: `${i.progress}%` }} />
                  </div>
                </div>
                <div className="text-sm font-bold text-gradient">{i.progress}%</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <div className="rounded-xl border border-border bg-card p-5">
            <h4 className="mb-3 font-semibold">Upcoming 1:1s</h4>
            {[
              { n: "Aisha Rahman", t: "Today, 2:00 PM" },
              { n: "Diego Martinez", t: "Tomorrow, 10:00 AM" },
              { n: "Yuki Tanaka", t: "Fri, 3:30 PM" },
            ].map((m, i) => (
              <div key={i} className="flex items-center gap-3 border-t border-border py-3 first:border-0 first:pt-0">
                <Calendar className="h-4 w-4 text-primary" />
                <div className="flex-1 text-sm">{m.n}</div>
                <span className="text-xs text-muted-foreground">{m.t}</span>
              </div>
            ))}
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <h4 className="mb-3 font-semibold">Pending Reviews</h4>
            {[
              { n: "Aisha — Week 8 Report" },
              { n: "Priya — Auth Module Demo" },
              { n: "Diego — UI Style Guide" },
            ].map((m, i) => (
              <div key={i} className="flex items-center gap-3 border-t border-border py-3 first:border-0 first:pt-0">
                <FileText className="h-4 w-4 text-accent" />
                <div className="flex-1 text-sm">{m.n}</div>
                <Button size="sm" variant="ghost" className="h-7 text-xs">Review</Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

function InternDashboard() {
  return (
    <Card className="overflow-hidden shadow-elegant">
      <ChromeBar title="internflow.app/intern" />
      <div className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-2xl font-bold">Hi Aisha 👋</h3>
            <p className="text-sm text-muted-foreground">You're 65% through your internship. Keep going!</p>
          </div>
          <Button size="sm" className="bg-gradient-primary"><FileText className="mr-1.5 h-4 w-4" /> Submit Report</Button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-4">
          <StatCard label="Tasks Open" value="5" icon={Clock} color="warning" />
          <StatCard label="Completed" value="23" trend="3 this week" icon={CheckCircle2} color="success" />
          <StatCard label="Reports" value="11" icon={FileText} />
          <StatCard label="Avg Score" value="94" icon={Star} color="success" />
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h4 className="font-semibold">My Tasks</h4>
              <span className="text-xs text-muted-foreground">5 open</span>
            </div>
            <ul className="space-y-3">
              {[
                { t: "Build authentication flow", d: "Due today", p: "high" },
                { t: "Submit weekly report #12", d: "Due tomorrow", p: "medium" },
                { t: "Refactor product API", d: "Due Fri", p: "medium" },
                { t: "Pair with senior dev", d: "Mon, 11AM", p: "low" },
                { t: "Read design system docs", d: "Anytime", p: "low" },
              ].map((task, i) => (
                <li key={i} className="flex items-center gap-3 rounded-lg border border-border bg-background p-3 transition-smooth hover:border-primary/40">
                  <input type="checkbox" className="h-4 w-4 rounded border-border accent-primary" />
                  <div className="flex-1">
                    <div className="text-sm font-medium">{task.t}</div>
                    <div className="text-xs text-muted-foreground">{task.d}</div>
                  </div>
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                    task.p === "high" ? "bg-destructive/15 text-destructive" :
                    task.p === "medium" ? "bg-warning/20 text-warning-foreground" :
                    "bg-muted text-muted-foreground"
                  }`}>{task.p}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-5">
              <h4 className="mb-3 font-semibold">Internship Progress</h4>
              <div className="relative mx-auto h-32 w-32">
                <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="var(--muted)" strokeWidth="10" />
                  <circle cx="50" cy="50" r="42" fill="none" stroke="url(#g1)" strokeWidth="10" strokeLinecap="round" strokeDasharray={`${65 * 2.64} 264`} />
                  <defs>
                    <linearGradient id="g1" x1="0" x2="1">
                      <stop offset="0" stopColor="oklch(0.55 0.19 255)" />
                      <stop offset="1" stopColor="oklch(0.72 0.17 195)" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-2xl font-bold text-gradient">65%</div>
                  <div className="text-[10px] text-muted-foreground">Week 8 / 12</div>
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-border bg-card p-5">
              <h4 className="mb-3 font-semibold">Latest Feedback</h4>
              <div className="rounded-lg bg-gradient-soft p-3 text-xs">
                <div className="flex items-center gap-1 text-warning">
                  {[1,2,3,4,5].map(i => <Star key={i} className="h-3 w-3 fill-current" />)}
                </div>
                <p className="mt-2 leading-relaxed">"Excellent work on the auth module — clean code and great test coverage!"</p>
                <p className="mt-2 font-semibold">— Marcus Patel</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
