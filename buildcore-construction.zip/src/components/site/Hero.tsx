import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";
import heroImage from "@/assets/hero-construction.jpg";

export const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      <img
        src={heroImage}
        alt="Construction site at sunset with cranes and steel structure"
        width={1920}
        height={1088}
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-hero" />

      <div className="container relative z-10 py-20">
        <div className="max-w-3xl animate-slide-up">
          <div className="inline-flex items-center gap-3 mb-6 px-4 py-2 bg-accent text-accent-foreground font-bold text-xs uppercase tracking-[0.25em]">
            <span className="w-2 h-2 bg-asphalt rounded-full animate-pulse" />
            Trusted Since 1999
          </div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl text-primary-foreground leading-[0.95] mb-6">
            We Build the
            <span className="block text-primary">Future, Strong.</span>
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/85 max-w-2xl mb-10 leading-relaxed">
            From towering skyscrapers to vital bridges and highways — BuildCore delivers world-class
            civil engineering with safety, precision, and craftsmanship at every level.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button asChild variant="hero" size="xl">
              <a href="#projects">
                Explore Projects <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
            <Button asChild variant="outlineLight" size="xl">
              <a href="#about">
                <Play className="w-4 h-4" /> Our Story
              </a>
            </Button>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-px bg-primary-foreground/10 max-w-4xl">
          {[
            ["480+", "Projects"],
            ["25+", "Years"],
            ["1.2K", "Workers"],
            ["98%", "On Time"],
          ].map(([v, l]) => (
            <div key={l} className="bg-asphalt/70 backdrop-blur p-6 text-center">
              <div className="font-display text-3xl md:text-4xl text-primary">{v}</div>
              <div className="text-xs uppercase tracking-[0.2em] text-primary-foreground/70 mt-1">{l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
