import { Building, Construction, Hammer, HardHat, Ruler, TrafficCone } from "lucide-react";

const services = [
  { icon: Building, title: "Building Construction", desc: "Commercial, residential and high-rise builds engineered to last generations." },
  { icon: TrafficCone, title: "Roads & Highways", desc: "Asphalt paving, expressway development, and urban roadway networks." },
  { icon: Construction, title: "Bridge Engineering", desc: "Suspension, cable-stayed, and overpass bridges with structural precision." },
  { icon: Ruler, title: "Architectural Design", desc: "Concept-to-completion design services led by award-winning architects." },
  { icon: Hammer, title: "Renovation & Retrofit", desc: "Modernizing legacy structures with seismic and sustainability upgrades." },
  { icon: HardHat, title: "Project Management", desc: "End-to-end planning, procurement, and on-site supervision teams." },
];

export const Services = () => {
  return (
    <section id="services" className="py-24 bg-asphalt text-asphalt-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: "radial-gradient(circle at 1px 1px, hsl(var(--primary)) 1px, transparent 0)",
        backgroundSize: "32px 32px",
      }} />
      <div className="container relative">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">What We Do</p>
          <h2 className="text-4xl md:text-5xl mb-4">Our Services</h2>
          <p className="text-concrete text-lg">
            Full-spectrum civil construction services — from blueprint to ribbon cutting.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-steel/40">
          {services.map((s) => (
            <div
              key={s.title}
              className="group bg-asphalt p-8 hover:bg-steel transition-smooth cursor-pointer relative"
            >
              <div className="absolute top-0 left-0 w-0 h-1 bg-primary group-hover:w-full transition-all duration-500" />
              <div className="w-14 h-14 bg-gradient-primary flex items-center justify-center mb-6 rounded-sm group-hover:shadow-glow transition-smooth">
                <s.icon className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="text-xl mb-3">{s.title}</h3>
              <p className="text-concrete leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
