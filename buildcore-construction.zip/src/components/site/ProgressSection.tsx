import { Progress } from "@/components/ui/progress";
import { Calendar, MapPin } from "lucide-react";

const ongoing = [
  { name: "Apex Tower — Phase 3", location: "Downtown Metro", deadline: "Q4 2025", progress: 78, status: "On Track" },
  { name: "Highway 87 Expansion", location: "North Corridor", deadline: "Q2 2026", progress: 45, status: "On Track" },
  { name: "Vertex Logistics Hub", location: "Port Sector", deadline: "Q1 2026", progress: 62, status: "Ahead" },
  { name: "Riverside Bridge Retrofit", location: "Harbor District", deadline: "Q3 2025", progress: 91, status: "Final Stage" },
];

const statusColor = (s: string) =>
  s === "Ahead" ? "bg-accent text-accent-foreground" :
  s === "Final Stage" ? "bg-primary text-primary-foreground" :
  "bg-secondary text-secondary-foreground";

export const ProgressSection = () => {
  return (
    <section id="progress" className="py-24 bg-background">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">Live Updates</p>
          <h2 className="text-4xl md:text-5xl mb-4">Work In Progress</h2>
          <p className="text-muted-foreground text-lg">
            Real-time visibility into every active project. Transparency is part of how we build.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {ongoing.map((p) => (
            <div key={p.name} className="bg-card border border-border p-6 md:p-8 shadow-card hover:shadow-elegant transition-smooth border-l-4 border-l-primary">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-xl md:text-2xl mb-2">{p.name}</h3>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-primary" />{p.location}</span>
                    <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4 text-primary" />Due {p.deadline}</span>
                  </div>
                </div>
                <span className={`px-3 py-1 text-xs font-bold uppercase tracking-wider whitespace-nowrap ${statusColor(p.status)}`}>
                  {p.status}
                </span>
              </div>

              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Completion</span>
                <span className="font-display text-2xl text-primary">{p.progress}%</span>
              </div>
              <Progress value={p.progress} className="h-3" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
