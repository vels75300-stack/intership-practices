import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, User } from "lucide-react";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";

const schema = z.object({
  email: z.string().trim().email({ message: "Enter a valid email" }).max(255),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }).max(100),
});

export const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse({ email, password });
    if (!r.success) {
      toast.error(r.error.issues[0].message);
      return;
    }
    toast.success("Welcome back! (Demo — connect Lovable Cloud for real auth)");
  };

  return (
    <section id="login" className="py-24 bg-gradient-dark text-asphalt-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: "linear-gradient(45deg, hsl(var(--primary)) 25%, transparent 25%, transparent 75%, hsl(var(--primary)) 75%), linear-gradient(45deg, hsl(var(--primary)) 25%, transparent 25%, transparent 75%, hsl(var(--primary)) 75%)",
        backgroundSize: "40px 40px",
        backgroundPosition: "0 0, 20px 20px",
      }} />
      <div className="container relative grid lg:grid-cols-2 gap-12 items-center max-w-5xl">
        <div>
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">Client Access</p>
          <h2 className="text-4xl md:text-5xl mb-6">Project Portal Login</h2>
          <p className="text-concrete text-lg leading-relaxed mb-6">
            Clients, contractors, and partners can log in to access blueprints, daily progress reports,
            invoices, and project documentation.
          </p>
          <ul className="space-y-3 text-concrete">
            {["Live progress tracking", "Document & blueprint access", "Direct PM communication", "Invoice & milestone billing"].map((f) => (
              <li key={f} className="flex items-center gap-3">
                <span className="w-1.5 h-1.5 bg-primary rounded-full" /> {f}
              </li>
            ))}
          </ul>
        </div>

        <form onSubmit={submit} className="bg-card text-card-foreground p-8 md:p-10 shadow-elegant border-t-4 border-primary">
          <h3 className="text-2xl mb-6 text-asphalt">Sign In</h3>
          <div className="space-y-5">
            <div>
              <Label htmlFor="email" className="uppercase text-xs tracking-wider font-bold">Email</Label>
              <div className="relative mt-2">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="email" type="email" placeholder="you@company.com" value={email} onChange={e => setEmail(e.target.value)} className="pl-10 h-12" maxLength={255} />
              </div>
            </div>
            <div>
              <Label htmlFor="password" className="uppercase text-xs tracking-wider font-bold">Password</Label>
              <div className="relative mt-2">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="password" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} className="pl-10 h-12" maxLength={100} />
              </div>
            </div>
            <Button type="submit" variant="hero" size="lg" className="w-full">Sign In to Portal</Button>
            <p className="text-xs text-center text-muted-foreground">
              Need access? <a href="#contact" className="text-primary font-semibold hover:underline">Contact your project manager</a>
            </p>
          </div>
        </form>
      </div>
    </section>
  );
};
