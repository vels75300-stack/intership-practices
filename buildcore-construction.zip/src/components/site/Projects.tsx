import { MapPin, Calendar } from "lucide-react";
import skyscraper from "@/assets/project-skyscraper.jpg";
import bridge from "@/assets/project-bridge.jpg";
import highway from "@/assets/project-highway.jpg";
import residential from "@/assets/project-residential.jpg";
import industrial from "@/assets/project-industrial.jpg";
import commercial from "@/assets/project-commercial.jpg";

const projects = [
  { img: skyscraper, title: "Apex Tower", category: "Commercial Skyscraper", location: "Downtown Metro", year: "2024" },
  { img: bridge, title: "Riverside Bridge", category: "Infrastructure", location: "Harbor District", year: "2023" },
  { img: highway, title: "Highway 87 Expansion", category: "Roads & Transit", location: "North Corridor", year: "2024" },
  { img: residential, title: "Solace Residences", category: "Residential", location: "West Heights", year: "2023" },
  { img: industrial, title: "Vertex Logistics Hub", category: "Industrial", location: "Port Sector", year: "2025" },
  { img: commercial, title: "Crown Plaza Mall", category: "Commercial", location: "City Center", year: "2024" },
];

export const Projects = () => {
  return (
    <section id="projects" className="py-24 bg-muted/40">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">Our Portfolio</p>
          <h2 className="text-4xl md:text-5xl mb-4">Featured Projects</h2>
          <p className="text-muted-foreground text-lg">
            A showcase of landmark structures that define skylines and connect communities.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p, i) => (
            <article
              key={p.title}
              className="group relative bg-card overflow-hidden shadow-card hover:shadow-elegant transition-smooth"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={p.img}
                  alt={`${p.title} — ${p.category}`}
                  width={800}
                  height={640}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-110 transition-smooth duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-asphalt/90 via-asphalt/20 to-transparent" />
                <span className="absolute top-4 left-4 bg-accent text-accent-foreground text-xs font-bold uppercase tracking-wider px-3 py-1">
                  {p.category}
                </span>
              </div>
              <div className="p-6 border-t-4 border-primary">
                <h3 className="text-2xl mb-3 group-hover:text-primary transition-smooth">{p.title}</h3>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-primary" />{p.location}</span>
                  <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4 text-primary" />{p.year}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
