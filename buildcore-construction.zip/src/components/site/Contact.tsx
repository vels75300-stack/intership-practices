import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Send } from "lucide-react";

const schema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Enter a valid email").max(255),
  phone: z.string().trim().min(7, "Enter a valid phone").max(20),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(1000),
});

export const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const upd = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm({ ...form, [k]: e.target.value });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse(form);
    if (!r.success) {
      toast.error(r.error.issues[0].message);
      return;
    }
    toast.success("Thanks! Our team will get back to you within 24 hours.");
    setForm({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <section id="contact" className="py-24 bg-asphalt text-asphalt-foreground">
      <div className="container max-w-4xl">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">Get In Touch</p>
          <h2 className="text-4xl md:text-5xl mb-4">Start Your Project</h2>
          <p className="text-concrete text-lg">
            Tell us about your project. Our engineers will respond within one business day.
          </p>
        </div>

        <form onSubmit={submit} className="bg-card text-card-foreground p-8 md:p-12 shadow-elegant border-t-4 border-primary">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name" className="uppercase text-xs tracking-wider font-bold">Full Name *</Label>
              <Input id="name" value={form.name} onChange={upd("name")} className="mt-2 h-12" maxLength={100} placeholder="John Doe" />
            </div>
            <div>
              <Label htmlFor="phone" className="uppercase text-xs tracking-wider font-bold">Phone *</Label>
              <Input id="phone" type="tel" value={form.phone} onChange={upd("phone")} className="mt-2 h-12" maxLength={20} placeholder="+1 (555) 000-0000" />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="email" className="uppercase text-xs tracking-wider font-bold">Email *</Label>
              <Input id="email" type="email" value={form.email} onChange={upd("email")} className="mt-2 h-12" maxLength={255} placeholder="you@company.com" />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="message" className="uppercase text-xs tracking-wider font-bold">Project Details *</Label>
              <Textarea id="message" value={form.message} onChange={upd("message")} rows={5} maxLength={1000} className="mt-2" placeholder="Tell us about your project scope, timeline and budget…" />
            </div>
          </div>
          <Button type="submit" variant="hero" size="xl" className="w-full mt-8">
            Send Message <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </section>
  );
};
