import { Building2, Award, Users, Calendar } from "lucide-react";
import aboutImage from "@/assets/about-team.jpg";

const stats = [
  { icon: Calendar, value: "25+", label: "Years Experience" },
  { icon: Building2, value: "480+", label: "Projects Delivered" },
  { icon: Users, value: "1.2K", label: "Skilled Workers" },
  { icon: Award, value: "60+", label: "Industry Awards" },
];

export const About = () => {
  return (
    <section id="about" className="py-24 bg-background">
      <div className="container grid lg:grid-cols-2 gap-12 items-center">
        <div className="relative animate-slide-up">
          <div className="absolute -top-4 -left-4 w-24 h-24 bg-accent z-0" />
          <div className="absolute -bottom-4 -right-4 w-32 h-32 border-4 border-primary z-0" />
          <img
            src={aboutImage}
            alt="BuildCore engineers reviewing blueprints on construction site"
            width={1200}
            height={800}
            loading="lazy"
            className="relative z-10 w-full h-[480px] object-cover shadow-card"
          />
        </div>

        <div>
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">About BuildCore</p>
          <h2 className="text-4xl md:text-5xl mb-6">
            Building Tomorrow's <span className="text-primary">Infrastructure</span> Today
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed mb-4">
            For over two decades, BuildCore has been at the forefront of civil engineering excellence. From towering skyscrapers
            to vital bridges and highways, we engineer the structures that move society forward.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-8">
            Our commitment to safety, precision, and sustainable construction practices has earned the trust of governments,
            developers, and communities across the country.
          </p>

          <div className="grid grid-cols-2 gap-6">
            {stats.map((s) => (
              <div key={s.label} className="flex items-start gap-4">
                <div className="w-12 h-12 bg-asphalt text-primary flex items-center justify-center shrink-0 rounded-sm">
                  <s.icon className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-display text-3xl text-asphalt">{s.value}</div>
                  <div className="text-sm text-muted-foreground uppercase tracking-wider">{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
