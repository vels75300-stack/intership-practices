import { MapPin, Phone, Mail, Clock } from "lucide-react";

export const Location = () => {
  return (
    <section id="location" className="py-24 bg-muted/40">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-primary font-bold uppercase tracking-[0.3em] text-sm mb-3">Find Us</p>
          <h2 className="text-4xl md:text-5xl mb-4">Our Location</h2>
          <p className="text-muted-foreground text-lg">Visit our headquarters or one of our regional offices.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 h-[480px] shadow-card overflow-hidden border-4 border-asphalt">
            <iframe
              title="BuildCore Headquarters Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.058379285672!2d-73.98784368459394!3d40.74844097932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9b3117469%3A0xd134e199a405a163!2sEmpire%20State%20Building!5e0!3m2!1sen!2sus!4v1644000000000"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <div className="space-y-4">
            {[
              { icon: MapPin, title: "Headquarters", lines: ["350 5th Avenue", "New York, NY 10118"] },
              { icon: Phone, title: "Phone", lines: ["+1 (555) 123-4567", "+1 (555) 987-6543"] },
              { icon: Mail, title: "Email", lines: ["info@buildcore.com", "projects@buildcore.com"] },
              { icon: Clock, title: "Hours", lines: ["Mon — Fri: 7AM – 6PM", "Sat: 8AM – 2PM"] },
            ].map((c) => (
              <div key={c.title} className="bg-card p-5 shadow-card border-l-4 border-primary flex gap-4 items-start">
                <div className="w-11 h-11 bg-asphalt text-primary flex items-center justify-center shrink-0 rounded-sm">
                  <c.icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-display uppercase tracking-wider text-sm text-asphalt mb-1">{c.title}</div>
                  {c.lines.map((l) => (
                    <div key={l} className="text-sm text-muted-foreground">{l}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
