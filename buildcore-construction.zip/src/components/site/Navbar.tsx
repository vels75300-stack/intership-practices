import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { HardHat, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const links = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Projects", href: "#projects" },
  { label: "Services", href: "#services" },
  { label: "Progress", href: "#progress" },
  { label: "Location", href: "#location" },
  { label: "Contact", href: "#contact" },
];

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 inset-x-0 z-50 transition-smooth",
        scrolled ? "bg-asphalt/95 backdrop-blur-md shadow-card" : "bg-asphalt/70 backdrop-blur-sm"
      )}
    >
      <div className="hazard-stripe" />
      <nav className="container flex items-center justify-between h-16 md:h-20">
        <Link to="/" className="flex items-center gap-2 text-asphalt-foreground">
          <div className="w-10 h-10 bg-gradient-primary flex items-center justify-center rounded-sm shadow-glow">
            <HardHat className="w-6 h-6 text-primary-foreground" />
          </div>
          <div className="font-display text-xl tracking-wider leading-none">
            BUILD<span className="text-primary">CORE</span>
            <div className="text-[10px] font-sans tracking-[0.3em] text-concrete">CONSTRUCTION</div>
          </div>
        </Link>

        <ul className="hidden lg:flex items-center gap-1">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="px-3 py-2 text-sm font-semibold uppercase tracking-wider text-asphalt-foreground/80 hover:text-primary transition-smooth"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden lg:block">
          <Button asChild variant="hero" size="default">
            <a href="#login">Login</a>
          </Button>
        </div>

        <button
          className="lg:hidden text-asphalt-foreground p-2"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {open && (
        <div className="lg:hidden bg-asphalt border-t border-steel">
          <ul className="container py-4 flex flex-col gap-1">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block px-3 py-3 text-sm font-semibold uppercase tracking-wider text-asphalt-foreground hover:text-primary"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <Button asChild variant="hero" className="w-full mt-2">
                <a href="#login" onClick={() => setOpen(false)}>Login</a>
              </Button>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
};
