import { HardHat, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-asphalt text-asphalt-foreground border-t border-steel">
      <div className="hazard-stripe" />
      <div className="container py-14 grid md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 bg-gradient-primary flex items-center justify-center rounded-sm">
              <HardHat className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="font-display text-xl tracking-wider">
              BUILD<span className="text-primary">CORE</span>
            </div>
          </div>
          <p className="text-concrete max-w-sm leading-relaxed">
            Building the future of infrastructure with safety, precision, and pride. Licensed in 32 states.
          </p>
          <div className="flex gap-3 mt-6">
            {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
              <a key={i} href="#" aria-label="Social link" className="w-10 h-10 border border-steel hover:bg-primary hover:border-primary flex items-center justify-center transition-smooth">
                <Icon className="w-4 h-4" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm mb-4 text-primary">Quick Links</h4>
          <ul className="space-y-2 text-concrete text-sm">
            {["About", "Projects", "Services", "Progress", "Contact"].map((l) => (
              <li key={l}><a href={`#${l.toLowerCase()}`} className="hover:text-primary transition-smooth">{l}</a></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-sm mb-4 text-primary">Contact</h4>
          <ul className="space-y-2 text-concrete text-sm">
            <li>350 5th Avenue, NY 10118</li>
            <li>+1 (555) 123-4567</li>
            <li>info@buildcore.com</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-steel">
        <div className="container py-5 flex flex-col md:flex-row justify-between items-center text-xs text-concrete gap-2">
          <p>© {new Date().getFullYear()} BuildCore Construction. All rights reserved.</p>
          <p className="uppercase tracking-[0.2em]">License #CCB-1849732 · Bonded · Insured</p>
        </div>
      </div>
    </footer>
  );
};
