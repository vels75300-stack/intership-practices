import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Projects } from "@/components/site/Projects";
import { Services } from "@/components/site/Services";
import { ProgressSection } from "@/components/site/ProgressSection";
import { Login } from "@/components/site/Login";
import { Location } from "@/components/site/Location";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";

const Index = () => {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <About />
      <Projects />
      <Services />
      <ProgressSection />
      <Login />
      <Location />
      <Contact />
      <Footer />
    </main>
  );
};

export default Index;
